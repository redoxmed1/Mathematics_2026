Professional graph images for Exercises 9 and 15

1. exercise_09_one_sided_limits.png
   Graph of f(x)=1/(x-2), with vertical asymptote x=2 and horizontal asymptote y=0.

2. exercise_15_sequence.png
   Sequence a_n=(1+1/n)^n, showing its discrete terms and limiting value e.
   The connecting curve is only a visual guide; the sequence is defined at integer n.

3. exercise_15_function.png
   Graph of f(x)=(x^2-4x+3)/(x-3), equivalent to y=x-1 for x != 3,
   with an open circle at the excluded point (3,2).
